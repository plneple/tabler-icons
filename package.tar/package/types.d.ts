import { ForwardRefExoticComponent, ReactSVG } from 'react';
import { SvgProps } from 'react-native-svg';
import * as reactNativeSvg from 'react-native-svg';
export { reactNativeSvg as NativeSvg };

type IconNode = [elementName: keyof ReactSVG, attrs: Record<string, string>][];
interface IconProps extends SvgProps {
    size?: string | number;
    strokeWidth?: string | number;
    title?: string;
}
type Icon = ForwardRefExoticComponent<IconProps>;

export type { Icon, IconNode, IconProps };
