/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconHomePlus = createReactNativeComponent("outline", "home-plus", "IconHomePlus", [["path", { "d": "M19 12h2l-9 -9l-9 9h2v7a2 2 0 0 0 2 2h5.5", "key": "svg-0" }], ["path", { "d": "M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2", "key": "svg-1" }], ["path", { "d": "M16 19h6", "key": "svg-2" }], ["path", { "d": "M19 16v6", "key": "svg-3" }]]);

export { IconHomePlus as default };
//# sourceMappingURL=IconHomePlus.mjs.map
