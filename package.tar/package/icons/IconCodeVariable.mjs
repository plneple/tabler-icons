/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconCodeVariable = createReactNativeComponent("outline", "code-variable", "IconCodeVariable", [["path", { "d": "M4 8m0 2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v4a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2z", "key": "svg-0" }]]);

export { IconCodeVariable as default };
//# sourceMappingURL=IconCodeVariable.mjs.map
