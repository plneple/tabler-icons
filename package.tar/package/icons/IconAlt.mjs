/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconAlt = createReactNativeComponent("outline", "alt", "IconAlt", [["path", { "d": "M4 16v-6a2 2 0 1 1 4 0v6", "key": "svg-0" }], ["path", { "d": "M4 13h4", "key": "svg-1" }], ["path", { "d": "M11 8v8h4", "key": "svg-2" }], ["path", { "d": "M16 8h4", "key": "svg-3" }], ["path", { "d": "M18 8v8", "key": "svg-4" }]]);

export { IconAlt as default };
//# sourceMappingURL=IconAlt.mjs.map
