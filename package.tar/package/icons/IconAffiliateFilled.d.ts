import { Icon } from '../types.js';

declare const _default: Icon;

export { _default as default };
