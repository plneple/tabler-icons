/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconPercentage33 = createReactNativeComponent("outline", "percentage-33", "IconPercentage33", [["path", { "d": "M12 3a9 9 0 0 1 7.794 13.5l-7.79 -4.497z", "fill": "currentColor", "stroke": "none", "key": "svg-0" }], ["path", { "d": "M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0", "key": "svg-1" }]]);

export { IconPercentage33 as default };
//# sourceMappingURL=IconPercentage33.mjs.map
