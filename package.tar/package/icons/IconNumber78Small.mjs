/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconNumber78Small = createReactNativeComponent("outline", "number-78-small", "IconNumber78Small", [["path", { "d": "M16 12h-1a1 1 0 0 1 -1 -1v-2a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1zh-1a1 1 0 0 0 -1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1 -1v-2a1 1 0 0 0 -1 -1", "key": "svg-0" }], ["path", { "d": "M6 8h4l-2 8", "key": "svg-1" }]]);

export { IconNumber78Small as default };
//# sourceMappingURL=IconNumber78Small.mjs.map
