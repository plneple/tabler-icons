/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconCircuitBattery = createReactNativeComponent("outline", "circuit-battery", "IconCircuitBattery", [["path", { "d": "M2 12h4", "key": "svg-0" }], ["path", { "d": "M18 12h4", "key": "svg-1" }], ["path", { "d": "M18 5v14", "key": "svg-2" }], ["path", { "d": "M14 9v6", "key": "svg-3" }], ["path", { "d": "M10 5v14", "key": "svg-4" }], ["path", { "d": "M6 9v6", "key": "svg-5" }]]);

export { IconCircuitBattery as default };
//# sourceMappingURL=IconCircuitBattery.mjs.map
