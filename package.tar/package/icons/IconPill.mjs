/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconPill = createReactNativeComponent("outline", "pill", "IconPill", [["path", { "d": "M4.5 12.5l8 -8a4.94 4.94 0 0 1 7 7l-8 8a4.94 4.94 0 0 1 -7 -7", "key": "svg-0" }], ["path", { "d": "M8.5 8.5l7 7", "key": "svg-1" }]]);

export { IconPill as default };
//# sourceMappingURL=IconPill.mjs.map
