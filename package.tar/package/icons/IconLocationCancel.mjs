/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconLocationCancel = createReactNativeComponent("outline", "location-cancel", "IconLocationCancel", [["path", { "d": "M12 18l-2 -4l-7 -3.5a.55 .55 0 0 1 0 -1l18 -6.5l-3.305 9.151", "key": "svg-0" }], ["path", { "d": "M19 19m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0", "key": "svg-1" }], ["path", { "d": "M17 21l4 -4", "key": "svg-2" }]]);

export { IconLocationCancel as default };
//# sourceMappingURL=IconLocationCancel.mjs.map
