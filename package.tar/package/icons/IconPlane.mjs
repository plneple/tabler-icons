/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconPlane = createReactNativeComponent("outline", "plane", "IconPlane", [["path", { "d": "M16 10h4a2 2 0 0 1 0 4h-4l-4 7h-3l2 -7h-4l-2 2h-3l2 -4l-2 -4h3l2 2h4l-2 -7h3z", "key": "svg-0" }]]);

export { IconPlane as default };
//# sourceMappingURL=IconPlane.mjs.map
