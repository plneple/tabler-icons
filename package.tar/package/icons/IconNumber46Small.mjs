/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconNumber46Small = createReactNativeComponent("outline", "number-46-small", "IconNumber46Small", [["path", { "d": "M18 9a1 1 0 0 0 -1 -1h-2a1 1 0 0 0 -1 1v6a1 1 0 0 0 1 1h2a1 1 0 0 0 1 -1v-2a1 1 0 0 0 -1 -1h-3", "key": "svg-0" }], ["path", { "d": "M6 8v3a1 1 0 0 0 1 1h3", "key": "svg-1" }], ["path", { "d": "M10 8v8", "key": "svg-2" }]]);

export { IconNumber46Small as default };
//# sourceMappingURL=IconNumber46Small.mjs.map
