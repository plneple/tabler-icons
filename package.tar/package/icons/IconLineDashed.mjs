/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconLineDashed = createReactNativeComponent("outline", "line-dashed", "IconLineDashed", [["path", { "d": "M5 12h2", "key": "svg-0" }], ["path", { "d": "M17 12h2", "key": "svg-1" }], ["path", { "d": "M11 12h2", "key": "svg-2" }]]);

export { IconLineDashed as default };
//# sourceMappingURL=IconLineDashed.mjs.map
