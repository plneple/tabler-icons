/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconAdjustmentsBolt = createReactNativeComponent("outline", "adjustments-bolt", "IconAdjustmentsBolt", [["path", { "d": "M4 10a2 2 0 1 0 4 0a2 2 0 0 0 -4 0", "key": "svg-0" }], ["path", { "d": "M6 4v4", "key": "svg-1" }], ["path", { "d": "M6 12v8", "key": "svg-2" }], ["path", { "d": "M10 16a2 2 0 1 0 4 0a2 2 0 0 0 -4 0", "key": "svg-3" }], ["path", { "d": "M12 4v10", "key": "svg-4" }], ["path", { "d": "M19 16l-2 3h4l-2 3", "key": "svg-5" }], ["path", { "d": "M12 18v2", "key": "svg-6" }], ["path", { "d": "M16 7a2 2 0 1 0 4 0a2 2 0 0 0 -4 0", "key": "svg-7" }], ["path", { "d": "M18 4v1", "key": "svg-8" }], ["path", { "d": "M18 9v3", "key": "svg-9" }]]);

export { IconAdjustmentsBolt as default };
//# sourceMappingURL=IconAdjustmentsBolt.mjs.map
