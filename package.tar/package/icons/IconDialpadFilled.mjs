/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconDialpadFilled = createReactNativeComponent("filled", "dialpad-filled", "IconDialpadFilled", [["path", { "d": "M6 2h-2a2 2 0 0 0 -2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2 -2v-2a2 2 0 0 0 -2 -2z", "key": "svg-0" }], ["path", { "d": "M20 2h-2a2 2 0 0 0 -2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2 -2v-2a2 2 0 0 0 -2 -2z", "key": "svg-1" }], ["path", { "d": "M13 2h-2a2 2 0 0 0 -2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2 -2v-2a2 2 0 0 0 -2 -2z", "key": "svg-2" }], ["path", { "d": "M6 9h-2a2 2 0 0 0 -2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2 -2v-2a2 2 0 0 0 -2 -2z", "key": "svg-3" }], ["path", { "d": "M20 9h-2a2 2 0 0 0 -2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2 -2v-2a2 2 0 0 0 -2 -2z", "key": "svg-4" }], ["path", { "d": "M13 9h-2a2 2 0 0 0 -2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2 -2v-2a2 2 0 0 0 -2 -2z", "key": "svg-5" }], ["path", { "d": "M13 16h-2a2 2 0 0 0 -2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2 -2v-2a2 2 0 0 0 -2 -2z", "key": "svg-6" }]]);

export { IconDialpadFilled as default };
//# sourceMappingURL=IconDialpadFilled.mjs.map
