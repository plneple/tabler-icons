/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconFolderSearch = createReactNativeComponent("outline", "folder-search", "IconFolderSearch", [["path", { "d": "M11 19h-6a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2h4l3 3h7a2 2 0 0 1 2 2v2.5", "key": "svg-0" }], ["path", { "d": "M18 18m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0", "key": "svg-1" }], ["path", { "d": "M20.2 20.2l1.8 1.8", "key": "svg-2" }]]);

export { IconFolderSearch as default };
//# sourceMappingURL=IconFolderSearch.mjs.map
