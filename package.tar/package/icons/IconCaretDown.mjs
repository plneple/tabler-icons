/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconCaretDown = createReactNativeComponent("outline", "caret-down", "IconCaretDown", [["path", { "d": "M6 10l6 6l6 -6h-12", "key": "svg-0" }]]);

export { IconCaretDown as default };
//# sourceMappingURL=IconCaretDown.mjs.map
