/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconTransitionTop = createReactNativeComponent("outline", "transition-top", "IconTransitionTop", [["path", { "d": "M21 6a3 3 0 0 0 -3 -3h-12a3 3 0 0 0 -3 3", "key": "svg-0" }], ["path", { "d": "M6 21h12a3 3 0 0 0 0 -6h-12a3 3 0 0 0 0 6z", "key": "svg-1" }], ["path", { "d": "M12 15v-8", "key": "svg-2" }], ["path", { "d": "M9 10l3 -3l3 3", "key": "svg-3" }]]);

export { IconTransitionTop as default };
//# sourceMappingURL=IconTransitionTop.mjs.map
