/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconCornerDownRight = createReactNativeComponent("outline", "corner-down-right", "IconCornerDownRight", [["path", { "d": "M6 6v6a3 3 0 0 0 3 3h10l-4 -4m0 8l4 -4", "key": "svg-0" }]]);

export { IconCornerDownRight as default };
//# sourceMappingURL=IconCornerDownRight.mjs.map
