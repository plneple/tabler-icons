/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconBrandGooglePodcasts = createReactNativeComponent("outline", "brand-google-podcasts", "IconBrandGooglePodcasts", [["path", { "d": "M12 3v2", "key": "svg-0" }], ["path", { "d": "M12 19v2", "key": "svg-1" }], ["path", { "d": "M12 8v8", "key": "svg-2" }], ["path", { "d": "M8 17v2", "key": "svg-3" }], ["path", { "d": "M4 11v2", "key": "svg-4" }], ["path", { "d": "M20 11v2", "key": "svg-5" }], ["path", { "d": "M8 5v8", "key": "svg-6" }], ["path", { "d": "M16 7v-2", "key": "svg-7" }], ["path", { "d": "M16 19v-8", "key": "svg-8" }]]);

export { IconBrandGooglePodcasts as default };
//# sourceMappingURL=IconBrandGooglePodcasts.mjs.map
