/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconGitCommit = createReactNativeComponent("outline", "git-commit", "IconGitCommit", [["path", { "d": "M12 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0", "key": "svg-0" }], ["path", { "d": "M12 3l0 6", "key": "svg-1" }], ["path", { "d": "M12 15l0 6", "key": "svg-2" }]]);

export { IconGitCommit as default };
//# sourceMappingURL=IconGitCommit.mjs.map
