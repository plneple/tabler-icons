/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconProtocol = createReactNativeComponent("outline", "protocol", "IconProtocol", [["path", { "d": "M15 6l-7 12", "key": "svg-0" }], ["path", { "d": "M20 6l-7 12", "key": "svg-1" }], ["path", { "d": "M5 14v.015", "key": "svg-2" }], ["path", { "d": "M5 10.015v.015", "key": "svg-3" }]]);

export { IconProtocol as default };
//# sourceMappingURL=IconProtocol.mjs.map
