/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconQrcodeOff = createReactNativeComponent("outline", "qrcode-off", "IconQrcodeOff", [["path", { "d": "M8 4h1a1 1 0 0 1 1 1v1m-.297 3.711a1 1 0 0 1 -.703 .289h-4a1 1 0 0 1 -1 -1v-4c0 -.275 .11 -.524 .29 -.705", "key": "svg-0" }], ["path", { "d": "M7 17v.01", "key": "svg-1" }], ["path", { "d": "M14 4m0 1a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1z", "key": "svg-2" }], ["path", { "d": "M7 7v.01", "key": "svg-3" }], ["path", { "d": "M4 14m0 1a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1z", "key": "svg-4" }], ["path", { "d": "M17 7v.01", "key": "svg-5" }], ["path", { "d": "M20 14v.01", "key": "svg-6" }], ["path", { "d": "M14 14v3", "key": "svg-7" }], ["path", { "d": "M14 20h3", "key": "svg-8" }], ["path", { "d": "M3 3l18 18", "key": "svg-9" }]]);

export { IconQrcodeOff as default };
//# sourceMappingURL=IconQrcodeOff.mjs.map
