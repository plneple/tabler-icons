/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconExchange = createReactNativeComponent("outline", "exchange", "IconExchange", [["path", { "d": "M5 18m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0", "key": "svg-0" }], ["path", { "d": "M19 6m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0", "key": "svg-1" }], ["path", { "d": "M19 8v5a5 5 0 0 1 -5 5h-3l3 -3m0 6l-3 -3", "key": "svg-2" }], ["path", { "d": "M5 16v-5a5 5 0 0 1 5 -5h3l-3 -3m0 6l3 -3", "key": "svg-3" }]]);

export { IconExchange as default };
//# sourceMappingURL=IconExchange.mjs.map
