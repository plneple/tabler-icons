/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconSquareChevronsUp = createReactNativeComponent("outline", "square-chevrons-up", "IconSquareChevronsUp", [["path", { "d": "M9 16l3 -3l3 3", "key": "svg-0" }], ["path", { "d": "M9 11l3 -3l3 3", "key": "svg-1" }], ["path", { "d": "M3 5a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-14z", "key": "svg-2" }]]);

export { IconSquareChevronsUp as default };
//# sourceMappingURL=IconSquareChevronsUp.mjs.map
