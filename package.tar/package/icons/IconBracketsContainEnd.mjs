/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconBracketsContainEnd = createReactNativeComponent("outline", "brackets-contain-end", "IconBracketsContainEnd", [["path", { "d": "M14 4h4v16h-4", "key": "svg-0" }], ["path", { "d": "M5 16h.01", "key": "svg-1" }], ["path", { "d": "M9 16h.01", "key": "svg-2" }], ["path", { "d": "M13 16h.01", "key": "svg-3" }]]);

export { IconBracketsContainEnd as default };
//# sourceMappingURL=IconBracketsContainEnd.mjs.map
