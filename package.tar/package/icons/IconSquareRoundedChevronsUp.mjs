/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconSquareRoundedChevronsUp = createReactNativeComponent("outline", "square-rounded-chevrons-up", "IconSquareRoundedChevronsUp", [["path", { "d": "M9 15l3 -3l3 3", "key": "svg-0" }], ["path", { "d": "M9 11l3 -3l3 3", "key": "svg-1" }], ["path", { "d": "M12 3c7.2 0 9 1.8 9 9s-1.8 9 -9 9s-9 -1.8 -9 -9s1.8 -9 9 -9z", "key": "svg-2" }]]);

export { IconSquareRoundedChevronsUp as default };
//# sourceMappingURL=IconSquareRoundedChevronsUp.mjs.map
