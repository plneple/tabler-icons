/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconPictureInPictureOn = createReactNativeComponent("outline", "picture-in-picture-on", "IconPictureInPictureOn", [["path", { "d": "M11 19h-6a2 2 0 0 1 -2 -2v-10a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v4", "key": "svg-0" }], ["path", { "d": "M14 14m0 1a1 1 0 0 1 1 -1h5a1 1 0 0 1 1 1v3a1 1 0 0 1 -1 1h-5a1 1 0 0 1 -1 -1z", "key": "svg-1" }], ["path", { "d": "M7 9l4 4", "key": "svg-2" }], ["path", { "d": "M8 13h3v-3", "key": "svg-3" }]]);

export { IconPictureInPictureOn as default };
//# sourceMappingURL=IconPictureInPictureOn.mjs.map
