/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconLetterQ = createReactNativeComponent("outline", "letter-q", "IconLetterQ", [["path", { "d": "M18 9a5 5 0 0 0 -5 -5h-2a5 5 0 0 0 -5 5v6a5 5 0 0 0 5 5h2a5 5 0 0 0 5 -5v-6", "key": "svg-0" }], ["path", { "d": "M13 15l5 5", "key": "svg-1" }]]);

export { IconLetterQ as default };
//# sourceMappingURL=IconLetterQ.mjs.map
