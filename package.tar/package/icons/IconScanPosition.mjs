/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconScanPosition = createReactNativeComponent("outline", "scan-position", "IconScanPosition", [["path", { "d": "M4 7v-1a2 2 0 0 1 2 -2h2", "key": "svg-0" }], ["path", { "d": "M4 17v1a2 2 0 0 0 2 2h2", "key": "svg-1" }], ["path", { "d": "M16 4h2a2 2 0 0 1 2 2v1", "key": "svg-2" }], ["path", { "d": "M16 20h2a2 2 0 0 0 2 -2v-1", "key": "svg-3" }], ["path", { "d": "M12 17l3 -8l-8 3l3.5 1.5z", "key": "svg-4" }]]);

export { IconScanPosition as default };
//# sourceMappingURL=IconScanPosition.mjs.map
