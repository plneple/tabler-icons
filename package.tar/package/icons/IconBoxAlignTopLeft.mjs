/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconBoxAlignTopLeft = createReactNativeComponent("outline", "box-align-top-left", "IconBoxAlignTopLeft", [["path", { "d": "M11 5v5a1 1 0 0 1 -1 1h-5a1 1 0 0 1 -1 -1v-5a1 1 0 0 1 1 -1h5a1 1 0 0 1 1 1z", "key": "svg-0" }], ["path", { "d": "M15 4h-.01", "key": "svg-1" }], ["path", { "d": "M20 4h-.01", "key": "svg-2" }], ["path", { "d": "M20 9h-.01", "key": "svg-3" }], ["path", { "d": "M20 15h-.01", "key": "svg-4" }], ["path", { "d": "M4 15h-.01", "key": "svg-5" }], ["path", { "d": "M20 20h-.01", "key": "svg-6" }], ["path", { "d": "M15 20h-.01", "key": "svg-7" }], ["path", { "d": "M9 20h-.01", "key": "svg-8" }], ["path", { "d": "M4 20h-.01", "key": "svg-9" }]]);

export { IconBoxAlignTopLeft as default };
//# sourceMappingURL=IconBoxAlignTopLeft.mjs.map
