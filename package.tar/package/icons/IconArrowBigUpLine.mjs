/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconArrowBigUpLine = createReactNativeComponent("outline", "arrow-big-up-line", "IconArrowBigUpLine", [["path", { "d": "M9 12h-3.586a1 1 0 0 1 -.707 -1.707l6.586 -6.586a1 1 0 0 1 1.414 0l6.586 6.586a1 1 0 0 1 -.707 1.707h-3.586v6h-6v-6z", "key": "svg-0" }], ["path", { "d": "M9 21h6", "key": "svg-1" }]]);

export { IconArrowBigUpLine as default };
//# sourceMappingURL=IconArrowBigUpLine.mjs.map
