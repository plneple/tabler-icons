/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconLetterP = createReactNativeComponent("outline", "letter-p", "IconLetterP", [["path", { "d": "M7 20v-16h5.5a4 4 0 0 1 0 9h-5.5", "key": "svg-0" }]]);

export { IconLetterP as default };
//# sourceMappingURL=IconLetterP.mjs.map
