/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconDeviceWatchCheck = createReactNativeComponent("outline", "device-watch-check", "IconDeviceWatchCheck", [["path", { "d": "M11 18h-2a3 3 0 0 1 -3 -3v-6a3 3 0 0 1 3 -3h6a3 3 0 0 1 3 3v5.5", "key": "svg-0" }], ["path", { "d": "M9 18v3h2.5", "key": "svg-1" }], ["path", { "d": "M9 6v-3h6v3", "key": "svg-2" }], ["path", { "d": "M15 19l2 2l4 -4", "key": "svg-3" }]]);

export { IconDeviceWatchCheck as default };
//# sourceMappingURL=IconDeviceWatchCheck.mjs.map
