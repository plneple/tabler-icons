/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconBrandFortnite = createReactNativeComponent("outline", "brand-fortnite", "IconBrandFortnite", [["path", { "d": "M8 3h7.5l-.5 4h-3v3h3v3.5h-3v6.5l-4 1z", "key": "svg-0" }]]);

export { IconBrandFortnite as default };
//# sourceMappingURL=IconBrandFortnite.mjs.map
