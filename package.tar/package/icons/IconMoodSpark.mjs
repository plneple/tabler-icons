/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconMoodSpark = createReactNativeComponent("outline", "mood-spark", "IconMoodSpark", [["path", { "d": "M21 12a9 9 0 1 0 -8.994 9", "key": "svg-0" }], ["path", { "d": "M9 10h.01", "key": "svg-1" }], ["path", { "d": "M15 10h.01", "key": "svg-2" }], ["path", { "d": "M9.5 15a3.5 3.5 0 0 0 5 0", "key": "svg-3" }], ["path", { "d": "M19 22.5a4.75 4.75 0 0 1 3.5 -3.5a4.75 4.75 0 0 1 -3.5 -3.5a4.75 4.75 0 0 1 -3.5 3.5a4.75 4.75 0 0 1 3.5 3.5", "key": "svg-4" }]]);

export { IconMoodSpark as default };
//# sourceMappingURL=IconMoodSpark.mjs.map
