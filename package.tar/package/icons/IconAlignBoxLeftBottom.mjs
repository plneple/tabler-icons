/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconAlignBoxLeftBottom = createReactNativeComponent("outline", "align-box-left-bottom", "IconAlignBoxLeftBottom", [["path", { "d": "M3 3m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z", "key": "svg-0" }], ["path", { "d": "M9 17h-2", "key": "svg-1" }], ["path", { "d": "M13 14h-6", "key": "svg-2" }], ["path", { "d": "M11 11h-4", "key": "svg-3" }]]);

export { IconAlignBoxLeftBottom as default };
//# sourceMappingURL=IconAlignBoxLeftBottom.mjs.map
