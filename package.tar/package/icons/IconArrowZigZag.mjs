/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconArrowZigZag = createReactNativeComponent("outline", "arrow-zig-zag", "IconArrowZigZag", [["path", { "d": "M6 20v-10l10 6v-12", "key": "svg-0" }], ["path", { "d": "M13 7l3 -3l3 3", "key": "svg-1" }]]);

export { IconArrowZigZag as default };
//# sourceMappingURL=IconArrowZigZag.mjs.map
