/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconCut = createReactNativeComponent("outline", "cut", "IconCut", [["path", { "d": "M7 17m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0", "key": "svg-0" }], ["path", { "d": "M17 17m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0", "key": "svg-1" }], ["path", { "d": "M9.15 14.85l8.85 -10.85", "key": "svg-2" }], ["path", { "d": "M6 4l8.85 10.85", "key": "svg-3" }]]);

export { IconCut as default };
//# sourceMappingURL=IconCut.mjs.map
