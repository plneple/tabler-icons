/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconBatteryVertical2Filled = createReactNativeComponent("filled", "battery-vertical-2-filled", "IconBatteryVertical2Filled", [["path", { "d": "M13.5 3a1.5 1.5 0 0 1 1.395 .948l.018 .052h.087a3 3 0 0 1 2.995 2.824l.005 .176v11a3 3 0 0 1 -3 3h-6a3 3 0 0 1 -3 -3v-11a3 3 0 0 1 3 -3h.086l.019 -.052a1.5 1.5 0 0 1 1.25 -.941l.145 -.007zm.5 13h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0 -2m0 -3h-4a1 1 0 0 0 0 2h4a1 1 0 0 0 0 -2", "key": "svg-0" }]]);

export { IconBatteryVertical2Filled as default };
//# sourceMappingURL=IconBatteryVertical2Filled.mjs.map
