/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconNumber79Small = createReactNativeComponent("outline", "number-79-small", "IconNumber79Small", [["path", { "d": "M14 15a1 1 0 0 0 1 1h2a1 1 0 0 0 1 -1v-6a1 1 0 0 0 -1 -1h-2a1 1 0 0 0 -1 1v2a1 1 0 0 0 1 1h3", "key": "svg-0" }], ["path", { "d": "M6 8h4l-2 8", "key": "svg-1" }]]);

export { IconNumber79Small as default };
//# sourceMappingURL=IconNumber79Small.mjs.map
