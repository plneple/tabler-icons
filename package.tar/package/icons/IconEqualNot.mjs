/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconEqualNot = createReactNativeComponent("outline", "equal-not", "IconEqualNot", [["path", { "d": "M5 10h14", "key": "svg-0" }], ["path", { "d": "M5 14h14", "key": "svg-1" }], ["path", { "d": "M5 19l14 -14", "key": "svg-2" }]]);

export { IconEqualNot as default };
//# sourceMappingURL=IconEqualNot.mjs.map
