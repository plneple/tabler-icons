/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconCircleHalf = createReactNativeComponent("outline", "circle-half", "IconCircleHalf", [["path", { "d": "M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0", "key": "svg-0" }], ["path", { "d": "M12 3v18", "key": "svg-1" }]]);

export { IconCircleHalf as default };
//# sourceMappingURL=IconCircleHalf.mjs.map
