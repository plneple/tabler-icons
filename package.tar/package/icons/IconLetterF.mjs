/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconLetterF = createReactNativeComponent("outline", "letter-f", "IconLetterF", [["path", { "d": "M17 4h-10v16", "key": "svg-0" }], ["path", { "d": "M7 12l8 0", "key": "svg-1" }]]);

export { IconLetterF as default };
//# sourceMappingURL=IconLetterF.mjs.map
