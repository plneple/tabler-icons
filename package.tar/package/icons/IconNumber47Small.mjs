/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconNumber47Small = createReactNativeComponent("outline", "number-47-small", "IconNumber47Small", [["path", { "d": "M14 8h4l-2 8", "key": "svg-0" }], ["path", { "d": "M6 8v3a1 1 0 0 0 1 1h3", "key": "svg-1" }], ["path", { "d": "M10 8v8", "key": "svg-2" }]]);

export { IconNumber47Small as default };
//# sourceMappingURL=IconNumber47Small.mjs.map
