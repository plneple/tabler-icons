/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconCurrencyYuan = createReactNativeComponent("outline", "currency-yuan", "IconCurrencyYuan", [["path", { "d": "M12 19v-7l-5 -7", "key": "svg-0" }], ["path", { "d": "M17 5l-5 7", "key": "svg-1" }], ["path", { "d": "M8 13h8", "key": "svg-2" }]]);

export { IconCurrencyYuan as default };
//# sourceMappingURL=IconCurrencyYuan.mjs.map
