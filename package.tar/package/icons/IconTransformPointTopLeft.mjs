/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconTransformPointTopLeft = createReactNativeComponent("outline", "transform-point-top-left", "IconTransformPointTopLeft", [["path", { "d": "M3 3m0 1a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1z", "fill": "currentColor", "key": "svg-0" }], ["path", { "d": "M3 17m0 1a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1z", "key": "svg-1" }], ["path", { "d": "M17 3m0 1a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1z", "key": "svg-2" }], ["path", { "d": "M17 17m0 1a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1z", "key": "svg-3" }], ["path", { "d": "M11 5h2", "key": "svg-4" }], ["path", { "d": "M5 11v2", "key": "svg-5" }], ["path", { "d": "M19 11v2", "key": "svg-6" }], ["path", { "d": "M11 19h2", "key": "svg-7" }]]);

export { IconTransformPointTopLeft as default };
//# sourceMappingURL=IconTransformPointTopLeft.mjs.map
