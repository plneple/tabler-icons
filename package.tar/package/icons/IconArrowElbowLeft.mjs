/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconArrowElbowLeft = createReactNativeComponent("outline", "arrow-elbow-left", "IconArrowElbowLeft", [["path", { "d": "M3 14v-6h6", "key": "svg-0" }], ["path", { "d": "M3 8l9 9l9 -9", "key": "svg-1" }]]);

export { IconArrowElbowLeft as default };
//# sourceMappingURL=IconArrowElbowLeft.mjs.map
