/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconExposureMinus2 = createReactNativeComponent("outline", "exposure-minus-2", "IconExposureMinus2", [["path", { "d": "M12 9a4 4 0 1 1 8 0c0 1.098 -.564 2.025 -1.159 2.815l-6.841 7.185h8", "key": "svg-0" }], ["path", { "d": "M3 12h6", "key": "svg-1" }]]);

export { IconExposureMinus2 as default };
//# sourceMappingURL=IconExposureMinus2.mjs.map
