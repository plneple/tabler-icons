/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconBuildingArch = createReactNativeComponent("outline", "building-arch", "IconBuildingArch", [["path", { "d": "M3 21l18 0", "key": "svg-0" }], ["path", { "d": "M4 21v-15a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v15", "key": "svg-1" }], ["path", { "d": "M9 21v-8a3 3 0 0 1 6 0v8", "key": "svg-2" }]]);

export { IconBuildingArch as default };
//# sourceMappingURL=IconBuildingArch.mjs.map
