/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconExclamationCircle = createReactNativeComponent("outline", "exclamation-circle", "IconExclamationCircle", [["path", { "d": "M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0", "key": "svg-0" }], ["path", { "d": "M12 9v4", "key": "svg-1" }], ["path", { "d": "M12 16v.01", "key": "svg-2" }]]);

export { IconExclamationCircle as default };
//# sourceMappingURL=IconExclamationCircle.mjs.map
