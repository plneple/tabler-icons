/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createReactNativeComponent from '../createReactNativeComponent.mjs';

var IconPictureInPictureFilled = createReactNativeComponent("filled", "picture-in-picture-filled", "IconPictureInPictureFilled", [["path", { "d": "M19 4a3 3 0 0 1 3 3v4a1 1 0 0 1 -2 0v-4a1 1 0 0 0 -1 -1h-14a1 1 0 0 0 -1 1v10a1 1 0 0 0 1 1h6a1 1 0 0 1 0 2h-6a3 3 0 0 1 -3 -3v-10a3 3 0 0 1 3 -3z", "key": "svg-0" }], ["path", { "d": "M20 13a2 2 0 0 1 2 2v3a2 2 0 0 1 -2 2h-5a2 2 0 0 1 -2 -2v-3a2 2 0 0 1 2 -2z", "key": "svg-1" }]]);

export { IconPictureInPictureFilled as default };
//# sourceMappingURL=IconPictureInPictureFilled.mjs.map
