/**
 * @license @tabler/icons-react-native v3.35.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */

import { forwardRef, createElement } from 'react';
import defaultAttributes, { childDefaultAttributes } from './defaultAttributes.mjs';
import * as NativeSvg from 'react-native-svg';

const createReactNativeComponent = (type, iconName, iconNamePascal, iconNode) => {
  const Component = forwardRef(
    ({ color = "currentColor", size = 24, strokeWidth = 1.5, title, children, ...rest }, ref) => {
      const customAttrs = {
        stroke: type === "filled" ? "none" : color,
        fill: type === "filled" ? color : "none",
        strokeWidth,
        ...rest
      };
      return createElement(
        NativeSvg.Svg,
        {
          ref,
          ...defaultAttributes[type],
          width: size,
          height: size,
          ...customAttrs,
          ...rest
        },
        [
          ...iconNode.map(([tag, attrs]) => {
            const upperCasedTag = tag.charAt(0).toUpperCase() + tag.slice(1);
            return createElement(
              NativeSvg[upperCasedTag],
              { ...childDefaultAttributes[type], ...customAttrs, ...attrs }
            );
          }),
          [
            title && createElement("title", { key: "svg-title" }, title),
            ...(Array.isArray(children) ? children : [children]) || []
          ]
        ]
      );
    }
  );
  Component.displayName = `${iconNamePascal}`;
  return Component;
};

export { createReactNativeComponent as default };
//# sourceMappingURL=createReactNativeComponent.mjs.map
