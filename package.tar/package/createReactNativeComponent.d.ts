import { IconNode, Icon } from './types.js';

declare const createReactNativeComponent: (type: "outline" | "filled", iconName: string, iconNamePascal: string, iconNode: IconNode) => Icon;

export { createReactNativeComponent as default };
